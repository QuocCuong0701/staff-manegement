package com.zk.viewmodel;

import com.zk.entity.Staff;
import com.zk.service.StaffService;
import com.zk.service.StaffServiceImpl;
import org.zkoss.bind.annotation.Init;
import org.zkoss.zul.ListModelList;

import java.util.List;

public class StaffViewModel {

    private StaffService staffService = new StaffServiceImpl();

    private ListModelList<Staff> staffListModel;
    private Staff selectStaff;

    @Init
    public void init() {
        List<Staff> staffList = staffService.getStaffList();
        staffListModel = new ListModelList<>(staffList);
    }


}
