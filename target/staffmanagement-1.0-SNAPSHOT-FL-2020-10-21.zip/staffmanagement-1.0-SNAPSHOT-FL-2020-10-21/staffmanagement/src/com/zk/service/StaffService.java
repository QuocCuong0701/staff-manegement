package com.zk.service;

import com.zk.entity.Staff;

import java.util.List;

public interface StaffService {

    List<Staff> getStaffList();

    Staff addStaff(Staff staff);

    Staff updateStaff(Staff staff);

    void deleteStaff(Staff staff);
}
